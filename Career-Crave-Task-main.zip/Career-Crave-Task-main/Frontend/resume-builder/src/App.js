import React from "react";
import "./App.css";
import ResumeSectionView from "./components/ResumeSectionView";

function App() {
  return (
    <div className="App">
      <ResumeSectionView />
    </div>
  );
}

export default App;
